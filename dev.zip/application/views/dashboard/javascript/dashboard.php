<!-- <script type="text/javascript">
$(function(){
	'use strict'
	$(document).ready(function(){

		const dt = $('#dt').DataTable({
			data : <?= json_encode($barang);?>,
			columns : [
				{ data : 'id_barang' },
				{ data : 'nama_barang' },
				{ data : 'nama_jenis' }
			]
		});

	});
});
</script> -->