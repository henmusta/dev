<div class="content">
	<div class="block">
		<div class="block-content">
			<div class="d-flex justify-content-end mb-2">
				<div class="btn-group btn-group-sm">
					<a target="_blank" class="btn btn-outline-secondary" href="<?= $module['url'];?>/print-out">
						<i class="fa fa-print"></i> Cetak
					</a>
				</div>
			</div>
			<table id="dt" class="table table-sm table-vcenter table-bordered" width="100%">
				<thead>
					<tr>
						<th>No.</th>
						<th>ID Barang</th>
						<th>Nama Barang</th>
						<th>Jenis Barang</th>
						<th>Stok</th>
						<th>Satuan</th>
					</tr>
				</thead>
				<tbody></tbody>
			</table>
		</div>
	</div>
</div>