<?php $penjualan = isset($data) ? $data : (object)[];?>
<script type="text/javascript">
$(function(){
	'use strict'
	$(document).ready(function(){
		
		$.fn.select2.defaults.set("width", "100%");

		$('#tgl-nota').datepicker({format:'yyyy-mm-dd',todayHighlight:true});

		$('.nama-pelanggan').typeahead({
		  source: function(query, result)
		  {
		  	$.ajax({
				url:"<?= $module['url'];?>/api-data/pelanggan-autocomplete",
				method:"POST",
				data:{phrase:query},
				dataType:"json",
				success:function(data)
				{
					result($.map(data, function(item){
					return item.nama.toString();
					}));
				}
			})
		  }
		 });

		$('#nama-pelanggan').focusout(function(){
			let nama = $(this).val();
			$.post(
				'<?= $module['url'];?>/api-data/get-kode-pelanggan-by-nama',
				{nama:nama}, function(response){
					if(response.status == 'success'){
						$('#alamat-pelanggan').val(response.alamat_pelanggan);
					} else {
						$('#alamat-pelanggan').val(null);
					}
				},
				'json'
				);
		});



		const currenciesOptions = {
			unformatOnSubmit            : true,
			decimalCharacterAlternative: ".",
			decimalPlaces: 0,
			//minimumValue: "0",
		};

		const 	totalItems 			= new AutoNumeric('#totalItems',currenciesOptions),
				discountItems 		= new AutoNumeric('#discountItems',currenciesOptions),
				billItems 			= new AutoNumeric('#billItems',currenciesOptions),
				totalPayments 		= new AutoNumeric('#totalPayments',currenciesOptions),
				totalReceivable 	= new AutoNumeric('#totalReceivable',currenciesOptions);

		$('#table-payments').on('changeTotalPayment', function(){

			let billItemsAmount = billItems.getNumber();
			let totalPaymentsAmount = 0;
			$(this).find('[id^="total_"]').each(function(){
				totalPaymentsAmount += AutoNumeric.getNumber(this);
			});
			totalPayments.set(totalPaymentsAmount);
			totalReceivable.set(billItemsAmount - totalPaymentsAmount);

			if (totalReceivable.get() > 0) {
				$('#additem').show();
			}else{
				$('#additem').hide();
			}

		});

		$('#table-items').on('changeTotalItem',	function(){
			let totalItemsAmount = 0;
			$(this).find('[id^="item_total_"]').each(function(){
				totalItemsAmount += AutoNumeric.getNumber(this);
			});
			let billItemsAmount = totalItemsAmount;
			totalItems.set(totalItemsAmount);
			let discountItemsAmount = AutoNumeric.getNumber($('#discountItems').get(0));
			billItemsAmount -= discountItemsAmount;
			billItems.set(billItemsAmount);
			$('#table-payments').trigger('changeTotalPayment');
		});
		const tableItems = $('#table-items').DataTable({
			paging		: false,
			searching 	: false,
			ordering 	: false,
			info 		: false,
			data 		: <?= isset($penjualan->rincian_penjualan) ? json_encode($penjualan->rincian_penjualan) : '[]' ;?>,
			columns : [
				{ 
					data : 'id_produk',
					render : function ( columnData, type, rowData, meta ) {
						let selectedOption = (columnData != null && columnData != '' && columnData != 0) ? `<option selected="selected" value="`+ columnData +`">`+ rowData.kode_pemasok+ ` / ` + rowData.nama +`</option>`: ``;
						return String(`<select class="form-control select2-produk" value="`+ columnData +`" name="rincian[`+ meta.row +`][id_produk]" required="required">`+ selectedOption +`</select>`).trim();
					}
				},
				{ 
					data 		: 'harga',
					className 	: 'text-right',
					width 		: '150px',
					render 		: function ( columnData, type, rowData, meta ) {
						return String(`
							<input id="item_harga_` + meta.row + `" class="form-control text-right" value="`+ columnData +`" name="rincian[`+ meta.row +`][harga]" data-column="harga" readonly="readonly">
						`).trim();
					}
				},
				{ 
					data 		: 'qty',
					className 	: 'text-right',
					width 		: '150px',
					render 		: function ( columnData, type, rowData, meta ) {
						return String(`
							<input id="item_qty_` + meta.row + `" class="form-control text-right" value="`+ columnData +`" name="rincian[`+ meta.row +`][qty]" data-column="qty">
						`).trim();
					}
				},
				{ 
					data 		: 'total',
					width 		: '150px',
					className 	: 'text-right',
					render 		: function ( columnData, type, rowData, meta ) {
						let total = parseInt(rowData.harga) * parseInt(rowData.qty);
						return String(`
							<input id="item_total_` + meta.row + `" class="form-control text-right" value="`+ total +`" name="rincian[`+ meta.row +`][total]" readonly="readonly" data-column="total">
						`).trim();
					}
				}
			],
			initComplete : function(settings, json){
				let api = this.api();
				$(api.table().footer()).find('.btn-add-row').click(function(){
					api.row.add({ nama : '', harga : 0, qty : 1, total : 0 }).draw();
				});
				$(api.table().footer()).find('.btn-delete-row').click(function(){
					api.row( ':last' ).remove().draw();
				});

				$('#discountItems').keyup(function(){
					$('#table-items').trigger('changeTotalItem');
				});
			},
			createdRow : function( row, data, index ){
				new AutoNumeric.multiple($(row).find('[id^="item"]').get(),currenciesOptions);
				$(row).find('.select2-produk').select2({
					ajax : {
						url 		: '<?= $module['url'];?>/api-data/select2-produk',
						dataType 	: 'json',
						type 		: 'POST',
						data 		: function (params) {
							var query = {
								search: params.term,
								type: 'public'
							}
							return $.extend({},params,{ kode_pelanggan: $('#select-pelanggan').val() });
						},
						processResults: function (myData) {
							var data = $.map(myData.results, function (obj) {
								obj.text = obj.text || obj.kode +' / '+ obj.nama_produk;
								obj.id = obj.id_produk;
								return obj;
							});
							return {
								results : data
							};
						}
					}
				}).on({
					'select2:select' : function(e){
						let data = e.params.data;
						AutoNumeric.getAutoNumericElement('#item_harga_' + index).set(data.harga_jual);
						$('#item_harga_' + index).trigger('keyup');
					}
				});
			},
			rowCallback : function( row, data, displayNum, displayIndex, index ){
				let api = this.api();
				$(row).find('#item_harga_' + index + ', ' + '#item_qty_' + index).keyup(function(){
					let harga 	= AutoNumeric.getNumber('#item_harga_' + index),
						qty 		= AutoNumeric.getNumber('#item_qty_' + index);
					AutoNumeric.getAutoNumericElement('#item_total_' + index).set(harga * qty);
					$('#table-items').trigger('changeTotalItem');
				});
			},
			drawCallback : function( settings ){
				$('#table-items').trigger('changeTotalItem');
			}
		});
		const tablePayments 	= $('#table-payments').DataTable({
			paging		: false,
			searching 	: false,
			ordering 	: false,
			info 		: false,
			data 		: <?= isset($penjualan->rincian_pelunasan) ? json_encode($penjualan->rincian_pelunasan) : '[]' ;?>,
			columns : [
				{ 
					data 	: 'metode',
					width 	: '120px',
					render 	: function ( columnData, type, rowData, meta ) {
						console.log(meta.row);
						return String(`
							<select class="form-control select2-metode" data-name="metode" required="required" name="pelunasan[`+ meta.row +`][metode]">
								<option value="tunai" `+ ( columnData == 'tunai' ? `selected="selected"` : ``) +`>Tunai</option>
								<option value="debit" `+ ( columnData == 'debit' ? `selected="selected"` : ``) +`>Debit</option>
								<option value="giro" `+ ( columnData == 'giro' ? `selected="selected"` : ``) +`>Giro</option>
							</select>
						`).trim();
					}
				},
				{ 
					data 	: 'id_akun',
					render 	: function ( columnData, type, rowData, meta ) {
						let selectedOption = (columnData != null && columnData != '' && columnData != 0) ? `<option selected="selected" value="`+ columnData +`">`+ rowData.nama_akun +`</option>`: ``;
						return String(`
							<select class="form-control select2-akun" data-column="id_akun" required="required" name="pelunasan[`+ meta.row +`][id_akun]">`+ selectedOption +`</select>
						`).trim();
					}
				},
				{ 
					data 		: 'nominal',
					width 		: '150px',
					className 	: 'text-right',
					render 		: function ( columnData, type, rowData, meta ) {
						return String(`
							<input id="nominal_`+ meta.row +`" class="form-control text-right" data-column="nominal" name="pelunasan[`+ meta.row +`][nominal]" value="`+ columnData +`">
						`).trim();
					}
				},
				{ 
					data 		: 'potongan',
					width 		: '150px',
					className 	: 'text-right',
					render 		: function ( columnData, type, rowData, meta ) {
						return String(`
							<input id="potongan_`+ meta.row +`" class="form-control text-right" data-column="potongan" name="pelunasan[`+ meta.row +`][potongan]" value="`+ columnData +`">
						`).trim();
					}
				},
				{ 
					data 		: 'total',
					width 		: '150px',
					className 	: 'text-right',
					render 		: function ( columnData, type, rowData, meta ) {
						return String(`
							<input id="total_`+ meta.row +`" class="form-control text-right" data-column="total" name="pelunasan[`+ meta.row +`][total]" value="`+ columnData +`" readonly="readonly">
						`).trim();
					}
				}
			],
			initComplete : function(settings, json){
				let api = this.api();

				$(api.table().footer()).find('.btn-add-row').click(function(){
					api.row.add({ metode : 'cash', akun : 0, nomor_giro : 1, tgl_giro : 0, nominal : 0, potongan : 0, total : 0 }).draw();
				});
				$(api.table().footer()).find('.btn-delete-row').click(function(){
					api.row( ':last' ).remove().draw();
				});
			},
			createdRow : function( row, data, index ){
				new AutoNumeric($(row).find('[id^="nominal"]').get(0),currenciesOptions);
				new AutoNumeric($(row).find('[id^="potongan"]').get(0),currenciesOptions);
				new AutoNumeric($(row).find('[id^="total_"]').get(0),currenciesOptions);
				$(row).find('.select2-metode').select2();
				$(row).find('.select2-akun').select2({
					ajax : {
						url 		: '<?= $module['url'];?>/api-data/select2-akun',
						dataType 	: 'json',
						type 		: 'POST',
						data 		: function (params) {
							var query = {
								search: params.term,
								type: 'public'
							}
							return $.extend({},params,{ metode: $(row).find('.select2-metode').val() });
						},
						processResults: function (myData) {
							var data = $.map(myData, function (obj) {
								obj.text = obj.text || obj.nama; // replace name with the property used for the text
								return obj;
							});
							return {
								results : data
							};
						}
					}
				});
			},
			rowCallback : function( row, data, displayNum, displayIndex, index ){
				$(row).find('.select2-metode').on({
					change : function(){
						let metode = $(this).val();
						$(row).find('.select2-akun').val(null).trigger('change');
					}
				});
				$(row).find('#nominal_' + index  + ', #potongan_' + index).keyup(function(){
					let nominal 	= AutoNumeric.getNumber('#nominal_' + index),
						potongan 	= AutoNumeric.getNumber('#potongan_' + index);
					AutoNumeric.getAutoNumericElement('#total_' + index).set(nominal + potongan);
					$('#table-payments').trigger('changeTotalPayment');
				});				
			},
			drawCallback : function( settings ){
				$('#table-payments').trigger('changeTotalPayment');
			}
		});
		$('form#form').validate({
            validClass      : 'is-valid',
            errorClass      : 'is-invalid',
            errorElement    : 'div',
            errorPlacement: function (error, element) {
                error.addClass('invalid-feedback');
                element.parent().append(error);
            },
			highlight		: function(element, errorClass, validClass) {
				$(element).removeClass(validClass).addClass(errorClass)
				.closest('.form-group').children('label').removeClass('text-success').addClass('text-danger');
			},
			unhighlight		: function(element, errorClass, validClass) {
				$(element).removeClass(errorClass).addClass(validClass)
				.closest('.form-group').children('label').removeClass('text-danger').addClass('text-success');
			},
			submitHandler	: function(form,eve) {
				eve.preventDefault();
				var btnSubmit 		= $(form).find("[type='submit']"),
					btnSubmitHtml 	= btnSubmit.html();

				$.ajax({
					cache 		: false,
					processData : false,
					contentType : false,
					type 		: 'POST',
					url 		: $(form).attr('action'),
					data 		: new FormData(form),
					dataType	: 'JSON',
					beforeSend:function() { 
						btnSubmit.addClass("disabled").html("<i class='fas fa-spinner fa-pulse fa-fw'></i> Loading ... ");
					},
					error 		: function(){
						btnSubmit.removeClass("disabled").html(btnSubmitHtml);
						$.notify({ icon: 'fa fa-exclamation mr-1', message: 'Server\'s response not found'}, {type: 'danger'});
					},
					success 	: function(response) {
						btnSubmit.removeClass("disabled").html(btnSubmitHtml);
						let timeout = 1000;
						if ( response.status == "success" ){
							$.notify( { icon: 'fa fa-check mr-1', message: response.message}, {type: 'success'});
							setTimeout(function(){
								if(response.redirect == "reload"){
									location.reload();
								} else if (response.redirect == "history.back()") {
									window.history.back();
								} else if(response.redirect != "") {
									location.href = response.redirect;
								}
							},timeout);
						} else {
							$.notify( {icon: 'fa fa-exclamation mr-1', message: response.message},{type: 'danger'});
						}
					}
				});
			}
		});

	});
});
</script>
